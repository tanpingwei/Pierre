package controller;

import model.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import service.UserService;
import javax.servlet.http.HttpServletResponse;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Roger on 2015/9/17.
 */
@Controller
public class UserController {
    @Resource(name = "userService")
    private UserService userService;

    @RequestMapping(value = "/user" ,method = RequestMethod.GET)
    public String getUser(Model model,String name) {
        System.out.println(userService.selectAll(name).size());
        List<User> users = userService.selectAll(name);
        model.addAttribute("user", users);
        return "listUser";
    }

    @RequestMapping(value = "/user" ,method = RequestMethod.POST)
    public String inserUser(Model model,String name) {
        System.out.println(userService.selectAll(name).size());
        userService.insert(name);
        model.addAttribute("code", 1);
        return "success";
    }

    @RequestMapping(value = "/user" ,method = RequestMethod.PUT)
    public String updateUser(Model model,String name,int id) {
        System.out.println(name+"======"+id);
        userService.update(name,id);
        model.addAttribute("code", 2);
        return "success";
    }

    @RequestMapping(value = "/user" ,method = RequestMethod.DELETE)
    public String deleteUser(Model model,String name) {
        System.out.println(userService.selectAll(name).size());
        userService.delete(name);
        model.addAttribute("code", 3);
        return "success";
    }



//    @RequestMapping(value = "/gettime" ,method = RequestMethod.GET)
//    public Map<String, Object> getTime(HttpServletResponse response) {
//        SimpleDateFormat tempDate = new SimpleDateFormat("HH:mm:ss");
//        String datetime = tempDate.format(new java.util.Date());
//        Map<String, Object> map = new HashMap<String, Object>();
//        map.put("data", datetime);
//        return map;
//    }


}
