package service;

import model.User;

import java.util.List;

/**
 * Created by Roger on 2015/9/17.
 */
public interface UserService {

    public List<User> selectAll(String  name);

    public void insert(String name);

    public void update(String name,int id);

    public void delete(String name);


}
