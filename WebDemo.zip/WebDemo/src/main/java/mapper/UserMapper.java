package mapper;

import model.User;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by Roger on 2015/9/17.
 */
@Repository("userMapper")
public interface UserMapper {
    @Select("select * from user where name = #{name}")
    @Results(value = {@Result(id = true, property = "id", column = "id"),
                @Result(property = "name", column = "name")})
    public List<User> selectAll(String name);

    @Insert("insert into user(name) values(#{name})")
    @Results(value = {@Result(id = true,property = "id",column = "id"),
                @Result(property = "name",column = "name")})
    public void insert(String name);

    @Update("update user set name = #{name} where id = #{id}")
    @Results(value = {@Result(id = true,property = "id",column = "id"),
            @Result(property = "name",column = "name")})
    public void update(String name,int id);

    @Delete("delete from user where name=#{name}")
    @Results(value = {@Result(id = true,property = "id",column = "id"),
            @Result(property = "name",column = "name")})
    public void delete(String name);


}
